import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import dotenv from 'dotenv';
dotenv.config();

import { updateLeadStatus, assignLeadToSeller } from '../src/services/leadService';
import db from '../src/db';

describe('🧪 Teste do campo last_interaction_at via trigger', () => {
  let leadId1; // Para updateLeadStatus
  let leadId2; // Para assignLeadToSeller

  beforeAll(async () => {
    // Lead para o primeiro teste
    const r1 = await db.query(`
      INSERT INTO leads (name, city, status)
      VALUES ('Lead para updateStatus', 'Recife', 'Disponível')
      RETURNING id
    `);
    leadId1 = r1.rows[0].id;

    // Lead para o segundo teste
    const r2 = await db.query(`
      INSERT INTO leads (name, city, status)
      VALUES ('Lead para assignSeller', 'Recife', 'Disponível')
      RETURNING id
    `);
    leadId2 = r2.rows[0].id;
  });

  afterAll(async () => {
    await db.query('DELETE FROM leads WHERE id IN ($1, $2)', [leadId1, leadId2]);
    await db.end();
  });

  it('🔁 Deve alterar o valor de last_interaction_at após updateLeadStatus()', async () => {
    const before = await db.query('SELECT last_interaction_at FROM leads WHERE id = $1', [leadId1]);

    await new Promise(r => setTimeout(r, 1000)); // Espera para garantir mudança
    await updateLeadStatus(leadId1, 'Em Atendimento');

    const after = await db.query('SELECT last_interaction_at FROM leads WHERE id = $1', [leadId1]);

    console.log('⏱️ Antes:', before.rows[0].last_interaction_at);
    console.log('⏱️ Depois:', after.rows[0].last_interaction_at);

    expect(after.rows[0].last_interaction_at).not.toEqual(before.rows[0].last_interaction_at);
  });

  it('👤 Deve alterar o valor de last_interaction_at após assignLeadToSeller()', async () => {
    const before = await db.query('SELECT last_interaction_at FROM leads WHERE id = $1', [leadId2]);

    await new Promise(r => setTimeout(r, 1000));
    await assignLeadToSeller(leadId2, '065f81cd-b1bf-41db-8e65-3174401985e9'); 

    const after = await db.query('SELECT last_interaction_at FROM leads WHERE id = $1', [leadId2]);

    console.log('⏱️ Antes:', before.rows[0].last_interaction_at);
    console.log('⏱️ Depois:', after.rows[0].last_interaction_at);

    expect(after.rows[0].last_interaction_at).not.toEqual(before.rows[0].last_interaction_at);
  });
});
