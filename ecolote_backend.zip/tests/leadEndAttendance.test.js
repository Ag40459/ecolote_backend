import { describe, it, expect, vi, beforeEach } from 'vitest';
import request from 'supertest';
import app from '../src/app';
import jwt from 'jsonwebtoken';
import { resetLeadTestData } from './testUtil.test';


// Mock do `io` para o teste
const mockIo = {
  emit: vi.fn(),
};

// Teste de dados do vendedor e do lead
const TEST_SELLER_ID = '065f81cd-b1bf-41db-8e65-3174401985e9';
const TEST_LEAD_ID = '08002af8-77aa-4bd5-97f1-9d205afe95d3';

const TEST_JWT_TOKEN = jwt.sign(
  { id: TEST_SELLER_ID, tipo_usuario: 'seller' },
  process.env.JWT_SECRET,
  { expiresIn: '1h' }
);

describe("🧪 Fase 3: Encerrar Atendimento", () => {
  beforeEach(async () => {
  await resetLeadTestData(TEST_LEAD_ID);
  mockIo.emit.mockClear();
});

  it("✅ Deve encerrar atendimento com sucesso", async () => {
    app.set("io", mockIo);

    // Primeiro, inicia o atendimento
    const startRes = await request(app)
      .post(`/api/leads/${TEST_LEAD_ID}/start-attendance`)
      .set('Authorization', `Bearer ${TEST_JWT_TOKEN}`)
      .send();

    // Dados para encerrar o atendimento - usando status válido
    const attendanceDetails = {
      status: "Aguardando Retorno", // Status válido conforme constraint
      last_contact_method: "Telefone",
      last_contact_notes: "Cliente demonstrou interesse no produto",
      contact_successful: true,
      is_energy_from_other_source: false,
      lead_interest_level: "Alto",
      meeting_scheduled_at: "2024-01-15T10:00:00.000Z",
      follow_up_date: "2024-01-20T09:00:00.000Z",
      follow_up_notes: "Agendar apresentação do produto"
    };

    // Encerra o atendimento
    const res = await request(app)
      .post(`/api/leads/${TEST_LEAD_ID}/end-attendance`)
      .set('Authorization', `Bearer ${TEST_JWT_TOKEN}`)
      .send(attendanceDetails);

    expect(res.status).toBe(200);
    expect(res.body.status).toBe("Aguardando Retorno");
    expect(res.body.is_active_attendance).toBe(false);
    expect(res.body.attended_by_user_id).toBe(null);
    expect(res.body.last_contact_method).toBe("Telefone");
    expect(res.body.contact_successful).toBe(true);
    expect(res.body.contact_attempts).toBe(1);
    expect(res.body.lead_interest_level).toBe("Alto");
    expect(res.body.contact_history).toHaveLength(1);

    // Verifica se o método `emit` foi chamado com o evento correto
    expect(mockIo.emit).toHaveBeenCalledWith("leadUpdate", res.body);
  });

  it("✅ Deve encerrar atendimento com falha no contato", async () => {
    app.set("io", mockIo);

    // Primeiro, inicia o atendimento
    await request(app)
      .post(`/api/leads/${TEST_LEAD_ID}/start-attendance`)
      .set('Authorization', `Bearer ${TEST_JWT_TOKEN}`)
      .send();

    // Dados para encerrar o atendimento com falha - usando status válido
    const attendanceDetails = {
      status: "Não Interessado", // Status válido conforme constraint
      last_contact_method: "WhatsApp",
      last_contact_notes: "Cliente não respondeu às mensagens",
      contact_successful: false,
      is_energy_from_other_source: null,
      lead_interest_level: "Baixo",
      follow_up_date: "2024-01-25T14:00:00.000Z",
      follow_up_notes: "Tentar contato novamente em uma semana"
    };

    // Encerra o atendimento
    const res = await request(app)
      .post(`/api/leads/${TEST_LEAD_ID}/end-attendance`)
      .set('Authorization', `Bearer ${TEST_JWT_TOKEN}`)
      .send(attendanceDetails);

    expect(res.status).toBe(200);
    expect(res.body.status).toBe("Não Interessado");
    expect(res.body.is_active_attendance).toBe(false);
    expect(res.body.contact_successful).toBe(false);
    expect(res.body.lead_interest_level).toBe("Baixo");
    expect(res.body.contact_attempts).toBe(1);
  });

  it("🚫 Não deve permitir encerrar atendimento sem estar em atendimento", async () => {
    app.set("io", mockIo);

    // Tenta encerrar atendimento sem ter iniciado
    const attendanceDetails = {
      status: "Fechado", // Status válido conforme constraint
      last_contact_method: "Telefone",
      last_contact_notes: "Teste",
      contact_successful: true,
      is_energy_from_other_source: false,
      lead_interest_level: "Alto"
    };

    const res = await request(app)
      .post(`/api/leads/${TEST_LEAD_ID}/end-attendance`)
      .set('Authorization', `Bearer ${TEST_JWT_TOKEN}`)
      .send(attendanceDetails);

    expect(res.status).toBe(409);
    expect(res.body.error).toMatch(/não está em atendimento/i);
  });

  it("🚫 Não deve permitir encerrar atendimento de outro vendedor", async () => {
    app.set("io", mockIo);

    // Primeiro, inicia o atendimento
    await request(app)
      .post(`/api/leads/${TEST_LEAD_ID}/start-attendance`)
      .set('Authorization', `Bearer ${TEST_JWT_TOKEN}`)
      .send();

    // Cria token para outro vendedor
    const OTHER_SELLER_ID = '12345678-1234-1234-1234-123456789012';
    const OTHER_JWT_TOKEN = jwt.sign(
      { id: OTHER_SELLER_ID, tipo_usuario: 'seller' },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    // Tenta encerrar atendimento com outro vendedor
    const attendanceDetails = {
      status: "Fechado", // Status válido conforme constraint
      last_contact_method: "Telefone",
      last_contact_notes: "Teste",
      contact_successful: true,
      is_energy_from_other_source: false,
      lead_interest_level: "Alto"
    };

    const res = await request(app)
      .post(`/api/leads/${TEST_LEAD_ID}/end-attendance`)
      .set('Authorization', `Bearer ${OTHER_JWT_TOKEN}`)
      .send(attendanceDetails);

    expect(res.status).toBe(409);
    expect(res.body.error).toMatch(/não está em atendimento por este vendedor/i);
  });

  it("🚫 Deve retornar erro 400 para dados obrigatórios ausentes", async () => {
    app.set("io", mockIo);

    // Primeiro, inicia o atendimento
    await request(app)
      .post(`/api/leads/${TEST_LEAD_ID}/start-attendance`)
      .set('Authorization', `Bearer ${TEST_JWT_TOKEN}`)
      .send();

    // Tenta encerrar sem dados obrigatórios
    const incompleteDetails = {
      last_contact_notes: "Apenas notas, sem status nem método"
    };

    const res = await request(app)
      .post(`/api/leads/${TEST_LEAD_ID}/end-attendance`)
      .set('Authorization', `Bearer ${TEST_JWT_TOKEN}`)
      .send(incompleteDetails);

    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/Status e método de contato são obrigatórios/i);
  });

  it("✅ Deve incrementar contact_attempts corretamente", async () => {
    app.set("io", mockIo);

    // Primeiro atendimento
    await request(app)
      .post(`/api/leads/${TEST_LEAD_ID}/start-attendance`)
      .set('Authorization', `Bearer ${TEST_JWT_TOKEN}`)
      .send();

    const firstAttendanceDetails = {
      status: "Aguardando Retorno", // Status válido conforme constraint
      last_contact_method: "Telefone",
      last_contact_notes: "Primeira tentativa",
      contact_successful: false,
      is_energy_from_other_source: false,
      lead_interest_level: "Médio"
    };

    const firstRes = await request(app)
      .post(`/api/leads/${TEST_LEAD_ID}/end-attendance`)
      .set('Authorization', `Bearer ${TEST_JWT_TOKEN}`)
      .send(firstAttendanceDetails);

    expect(firstRes.body.contact_attempts).toBe(1);

    // Segundo atendimento
    await request(app)
      .post(`/api/leads/${TEST_LEAD_ID}/start-attendance`)
      .set('Authorization', `Bearer ${TEST_JWT_TOKEN}`)
      .send();

    const secondAttendanceDetails = {
      status: "Fechado", // Status válido conforme constraint
      last_contact_method: "WhatsApp",
      last_contact_notes: "Segunda tentativa bem-sucedida",
      contact_successful: true,
      is_energy_from_other_source: false,
      lead_interest_level: "Alto"
    };

    const secondRes = await request(app)
      .post(`/api/leads/${TEST_LEAD_ID}/end-attendance`)
      .set('Authorization', `Bearer ${TEST_JWT_TOKEN}`)
      .send(secondAttendanceDetails);

    expect(secondRes.body.contact_attempts).toBe(2);
    expect(secondRes.body.contact_history).toHaveLength(2);
  });
});

