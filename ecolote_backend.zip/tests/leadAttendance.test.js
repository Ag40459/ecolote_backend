import { describe, it, expect, vi, afterEach } from 'vitest'; // Adicione afterEach
import request from 'supertest';
import app from '../src/app';
import jwt from 'jsonwebtoken';
import { updateLeadStatus } from '../src/services/leadService'; // Importe a função para atualizar o status do lead

// Mock do `io` para o teste
const mockIo = {
  emit: vi.fn(),
};

// Teste de dados do vendedor e do lead
const TEST_SELLER_ID = '065f81cd-b1bf-41db-8e65-3174401985e9';
const TEST_LEAD_ID = '08002af8-77aa-4bd5-97f1-9d205afe95d3'; // Substitua pelo ID de um lead de teste

const TEST_JWT_TOKEN = jwt.sign(
  { id: TEST_SELLER_ID, tipo_usuario: 'seller' },
  process.env.JWT_SECRET,
  { expiresIn: '1h' }
);

describe("🧪 Fase 2: Iniciar Atendimento", () => {
  // Limpa o estado do lead após cada teste
  afterEach(async () => {
    // Reseta o status do lead para "Disponível" após cada teste
    await updateLeadStatus(TEST_LEAD_ID, 'Disponível');
    mockIo.emit.mockClear(); // Limpa os mocks do emit após cada teste
  });

  it("✅ Deve iniciar atendimento com sucesso", async () => {
    // Aqui, você mocka a instância de `io` para o `app`
    app.set("io", mockIo);

    // Realiza a requisição para iniciar o atendimento do lead
    const res = await request(app)
      .post(`/api/leads/${TEST_LEAD_ID}/start-attendance`)
      .set('Authorization', `Bearer ${TEST_JWT_TOKEN}`)
      .send();


    // Verifica que o status da resposta é 200 e que o atendimento foi iniciado com sucesso
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('Em Atendimento');
    expect(res.body.attended_by_user_id).toBe(TEST_SELLER_ID);

    // Verifica se o método `emit` foi chamado com o evento correto
    expect(mockIo.emit).toHaveBeenCalledWith("leadUpdate", res.body);
  });

  it("🚫 Não deve permitir iniciar atendimento duas vezes", async () => {
    // Aqui, você mocka a instância de `io` para o `app`
    app.set("io", mockIo);

    // Primeiro, inicie o atendimento para simular a condição de "já em atendimento"
    await request(app)
      .post(`/api/leads/${TEST_LEAD_ID}/start-attendance`)
      .set('Authorization', `Bearer ${TEST_JWT_TOKEN}`)
      .send();

    // Realiza a requisição novamente para o mesmo lead
    const res = await request(app)
      .post(`/api/leads/${TEST_LEAD_ID}/start-attendance`)
      .set('Authorization', `Bearer ${TEST_JWT_TOKEN}`)
      .send();

    console.log('Resposta:', res.body);

    // Verifica que o status da resposta é 409 (Conflito) e que o erro está relacionado ao fato de já estar sendo atendido
    expect(res.status).toBe(409);
    expect(res.body.error).toMatch(/já está sendo atendido/i);
  });
});
