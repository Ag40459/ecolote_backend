// src/utils/testUtils.js
import supabase from '../src/config/supabaseClient';

export async function resetLeadTestData(leadId) {
  await supabase
    .from('leads')
    .update({
      status: 'Disponível',
      contact_attempts: 0,
      contact_history: [],
      is_active_attendance: false,
      attended_by_user_id: null
    })
    .eq('id', leadId);
}
