import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import dotenv from 'dotenv';
dotenv.config();

const request = require("supertest");
const app = require("../src/app");

describe("Reactivation Service Tests", () => {
  let authToken;
  let testLeadId;

  beforeAll(async () => {
    // Aqui você precisaria fazer login para obter o token
    // Este é um exemplo básico - ajuste conforme sua autenticação
    const loginResponse = await request(app)
      .post("/api/admin/login")
      .send({
        email: "test@example.com",
        password: "testpassword"
      });
    
    authToken = loginResponse.body.token;
  });

  describe("GET /api/leads/awaiting-reactivation", () => {
    it("should return leads awaiting reactivation for authenticated user", async () => {
      const response = await request(app)
        .get("/api/leads/awaiting-reactivation")
        .set("Authorization", `Bearer ${authToken}`)
        .expect(200);

      expect(Array.isArray(response.body)).toBe(true);
    });

    it("should return 401 for unauthenticated request", async () => {
      await request(app)
        .get("/api/leads/awaiting-reactivation")
        .expect(401);
    });
  });

  describe("POST /api/leads/process-inactive", () => {
    it("should process inactive leads", async () => {
      const response = await request(app)
        .post("/api/leads/process-inactive")
        .set("Authorization", `Bearer ${authToken}`)
        .expect(200);

      expect(response.body).toHaveProperty("processedCount");
      expect(response.body).toHaveProperty("updatedCount");
      expect(response.body).toHaveProperty("leads");
    });
  });

  describe("PUT /api/leads/:leadId/reactivate", () => {
    it("should reactivate a lead with valid data", async () => {
      // Primeiro, você precisaria criar um lead de teste ou usar um existente
      // Este é um exemplo básico
      if (testLeadId) {
        const response = await request(app)
          .put(`/api/leads/${testLeadId}/reactivate`)
          .set("Authorization", `Bearer ${authToken}`)
          .send({
            newStatus: "Em Atendimento",
            notes: "Reativando lead para novo atendimento"
          })
          .expect(200);

        expect(response.body).toHaveProperty("status", "Em Atendimento");
      }
    });

    it("should return 400 for missing newStatus", async () => {
      if (testLeadId) {
        await request(app)
          .put(`/api/leads/${testLeadId}/reactivate`)
          .set("Authorization", `Bearer ${authToken}`)
          .send({
            notes: "Tentativa sem status"
          })
          .expect(400);
      }
    });
  });

  describe("PUT /api/leads/:leadId/discard", () => {
    it("should discard a lead", async () => {
      if (testLeadId) {
        const response = await request(app)
          .put(`/api/leads/${testLeadId}/discard`)
          .set("Authorization", `Bearer ${authToken}`)
          .send({
            reason: "Sem Interesse"
          })
          .expect(200);

        expect(response.body.status).toMatch(/Descartado/);
      }
    });
  });

  describe("PUT /api/leads/:leadId/extend-deadline", () => {
    it("should extend reactivation deadline", async () => {
      if (testLeadId) {
        const response = await request(app)
          .put(`/api/leads/${testLeadId}/extend-deadline`)
          .set("Authorization", `Bearer ${authToken}`)
          .send({
            extensionDays: 30,
            notes: "Cliente solicitou mais tempo para decidir"
          })
          .expect(200);

        expect(response.body).toHaveProperty("reactivation_due_date");
        expect(response.body).toHaveProperty("reactivation_notes");
      }
    });

    it("should return 400 for invalid extension days", async () => {
      if (testLeadId) {
        await request(app)
          .put(`/api/leads/${testLeadId}/extend-deadline`)
          .set("Authorization", `Bearer ${authToken}`)
          .send({
            extensionDays: 45, // Valor inválido
            notes: "Tentativa com dias inválidos"
          })
          .expect(400);
      }
    });

    it("should return 400 for missing notes", async () => {
      if (testLeadId) {
        await request(app)
          .put(`/api/leads/${testLeadId}/extend-deadline`)
          .set("Authorization", `Bearer ${authToken}`)
          .send({
            extensionDays: 30
            // notes ausentes
          })
          .expect(400);
      }
    });
  });
});

// Teste de integração para o job de leads inativos
describe("Inactive Leads Job", () => {
  const { runInactiveLeadsJob } = require("../src/jobs/inactiveLeadsJob");

  it("should run without errors", async () => {
    const result = await runInactiveLeadsJob();
    
    expect(result).toHaveProperty("processedCount");
    expect(result).toHaveProperty("updatedCount");
    expect(result).toHaveProperty("leads");
    expect(typeof result.processedCount).toBe("number");
    expect(typeof result.updatedCount).toBe("number");
    expect(Array.isArray(result.leads)).toBe(true);
  });
});

