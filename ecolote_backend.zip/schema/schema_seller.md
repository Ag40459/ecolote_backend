# 📄 Esquema Completo da Tabela `leads` (schema: Seller) - ATUALIZADO

Este documento detalha todas as colunas da tabela `leads`, seus tipos e finalidades com base no schema SQL fornecido, incluindo as novas funcionalidades.

---

## 🎯 Identificação
| Coluna       | Tipo SQL  | Descrição                                                                 |
|--------------|-----------|---------------------------------------------------------------------------|
| `id`         | UUID      | Identificador único. Gerado automaticamente com `gen_random_uuid()`.     |
| `place_id`   | TEXT      | ID no Google Places. Deve ser único para evitar duplicação.              |

## 📍 Localização e Origem
| Coluna              | Tipo SQL       | Descrição                                                              |
|---------------------|----------------|------------------------------------------------------------------------|
| `name`              | TEXT           | Nome do local (condomínio, hotel etc.).                                |
| `formatted_address` | TEXT           | Endereço completo retornado pela API do Google.                        |
| `city`              | TEXT           | Cidade do local.                                                       |
| `state`             | TEXT           | Estado (UF) do local.                                                  |
| `neighborhood`      | TEXT           | Bairro do local.                                                       |
| `formatted_phone_number` | TEXT     | Telefone principal do local.                                           |
| `latitude`          | DECIMAL(10,8)  | Latitude para uso em mapa.                                             |
| `longitude`         | DECIMAL(11,8)  | Longitude para uso em mapa.                                            |
| `image_urls`        | TEXT[]         | Lista de URLs de imagens (carrossel).                                  |
| `type`              | TEXT           | Categoria do local ("Condomínio", "Hotel", etc).                       |
| `collected_at`      | TIMESTAMPTZ    | Timestamp da coleta do lead.                                           |

## 📞 Contato e Follow-up
| Coluna               | Tipo SQL    | Descrição                                                               |
|----------------------|-------------|-------------------------------------------------------------------------|
| `last_contact_at`     | TIMESTAMPTZ| Data do último contato feito.                                           |
| `last_contact_method` | TEXT       | Método de contato (WhatsApp, ligação etc.).                             |
| `last_contact_notes`  | TEXT       | Observações sobre o contato.                                            |
| `follow_up_date`      | DATE       | Próxima data de follow-up agendada.                                     |
| `follow_up_notes`     | TEXT       | Notas sobre o próximo contato.                                          |
| `contact_successful`   | BOOLEAN    | Indica se o contato inicial com o número cadastrado foi bem-sucedido.     |
| `contact_attempts`     | INTEGER    | Contador de tentativas de contato para o lead.                            |
| `contact_history`      | JSONB      | Histórico detalhado de todas as tentativas de contato.                    |

## 👤 Qualificação
| Coluna                           | Tipo SQL       | Descrição                                                              |
|----------------------------------|----------------|------------------------------------------------------------------------|
| `responsible_person_name`       | TEXT           | Nome do responsável pelo local.                                        |
| `responsible_person_phone_numbers` | TEXT[]      | Telefones adicionais do responsável.                                   |
| `client_email`                  | TEXT           | Email de contato.                                                      |
| `current_light_bill_value`      | DECIMAL(10,2)  | Valor da conta de energia mais recente (R$).                           |
| `last_kwh_consumption`          | DECIMAL(10,2)  | Consumo de energia (kWh) mais recente.                                 |
| `is_energy_from_other_source`   | BOOLEAN        | Se já usa energia de outra fonte (solar, etc).                         |
| `payment_preference`            | TEXT           | Preferência de pagamento (à vista, financiamento etc.).                |
| `payment_type`                  | TEXT           | Tipo de pagamento (CDC, consórcio etc.).                               |
| `bank_approval_status`          | TEXT           | Status da aprovação bancária.                                          |
| `proposal_generated_at`         | TIMESTAMPTZ    | Data/hora da geração da proposta.                                      |
| `proposal_url`                  | TEXT           | Link direto para proposta comercial.                                   |
| `lead_interest_level`          | TEXT           | Nível de interesse do cliente (opções pré-definidas).                     |
| `meeting_scheduled_at`         | TIMESTAMPTZ    | Data e hora da reunião agendada com o cliente.                            |

## 🔄 Gestão de Atendimento
| Coluna                  | Tipo SQL     | Descrição                                                             |
|-------------------------|--------------|------------------------------------------------------------------------|
| `status`                | TEXT         | Status atual do lead. Ex: “Disponível”, “Fechado”, “Em Atendimento”… |
| `last_status_update_at` | TIMESTAMPTZ  | Última vez que o status foi alterado.                                |
| `assigned_to_user_id`   | UUID         | ID do usuário ao qual o lead foi atribuído.                          |
| `assigned_at`           | TIMESTAMPTZ  | Quando o lead foi atribuído.                                         |
| `attended_by_user_id`   | UUID         | Usuário que iniciou o último atendimento.                            |
| `attended_at`           | TIMESTAMPTZ  | Quando o atendimento foi iniciado.                                   |
| `is_active_attendance`  | BOOLEAN      | TRUE se atendimento está ativo. Default: FALSE.                      |
| `last_attended_by_user_id` | UUID      | ID do último vendedor que iniciou atendimento ou teve o lead atribuído.   |
| `last_attended_at`     | TIMESTAMPTZ  | Data/hora do último atendimento iniciado ou atribuição.                   |
| `last_interaction_at`  | TIMESTAMPTZ  | Data/hora da última interação (qualquer atualização do lead).             |
| `reactivation_due_date`| DATE         | Data limite para reativação do lead após 15 dias de inatividade.          |
| `reactivation_notes`   | TEXT         | Notas sobre o motivo da extensão do prazo de reativação.                  |

## 🗑️ Motivos e Justificativas
| Coluna                    | Tipo SQL | Descrição                                                           |
|---------------------------|----------|---------------------------------------------------------------------|
| `discard_reason`          | TEXT     | Motivo para descarte do lead.                                       |
| `extended_follow_up_reason` | TEXT   | Justificativa para prolongar follow-up (>20 dias).                  |

## 🕓 Auditoria
| Coluna       | Tipo SQL    | Descrição                                                            |
|--------------|-------------|----------------------------------------------------------------------|
| `created_at` | TIMESTAMPTZ | Data de criação do registro (default NOW()).                        |
| `updated_at` | TIMESTAMPTZ | Atualizado automaticamente via trigger em cada update (ver abaixo). |

---

## ⚙️ Extras Técnicos

- **Trigger `set_updated_at_on_leads`**: mantém o campo `updated_at` sempre atualizado automaticamente.
- **Constraint de status (`chk_leads_status_valid`)**: permite apenas valores conhecidos.
- **Índices**: otimizam consultas por `status`, `assigned_to_user_id`, `city/state/type`, `collected_at`, `follow_up_date`.

---

**Atualizado em:** Junho/2025

