CREATE TABLE lead_status_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lead_id UUID NOT NULL,
    old_status TEXT NOT NULL,
    new_status TEXT NOT NULL,
    changed_by UUID NOT NULL, -- Assumindo que existe uma tabela de usuários com UUID
    changed_at TIMESTAMPTZ DEFAULT NOW(),
    notes TEXT,
    FOREIGN KEY (lead_id) REFERENCES leads(id)
);

-- Opcional: Adicionar índices para otimização de consultas
CREATE INDEX idx_lead_status_history_lead_id ON lead_status_history (lead_id);
CREATE INDEX idx_lead_status_history_changed_at ON lead_status_history (changed_at);



