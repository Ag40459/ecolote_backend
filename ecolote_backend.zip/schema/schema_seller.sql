-- Extensão necessária para UUIDs aleatórios
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ==============================================================
--  Tabela: leads  (schema Seller)
--  OBS.: Somente a coluna id é obrigatória. Todas as outras são
--        opcionais para facilitar importação incremental.
-- ==============================================================
CREATE TABLE IF NOT EXISTS leads (
    id                              UUID PRIMARY KEY                DEFAULT gen_random_uuid(),

    -- Dados do local (Google Places)
    place_id                        TEXT UNIQUE,
    name                            TEXT,
    formatted_address               TEXT,
    city                            TEXT,
    state                           TEXT,
    neighborhood                    TEXT,
    formatted_phone_number          TEXT,
    latitude                        DECIMAL(10,8),
    longitude                       DECIMAL(11,8),
    image_urls                      TEXT[],
    type                            TEXT,
    collected_at                    TIMESTAMPTZ,

    -- Gestão de atendimento
    status                          TEXT,
    last_status_update_at           TIMESTAMPTZ,
    assigned_to_user_id             UUID,
    assigned_at                     TIMESTAMPTZ,
    attended_by_user_id             UUID,
    attended_at                     TIMESTAMPTZ,
    is_active_attendance            BOOLEAN                         DEFAULT FALSE,

    -- Contato e follow‑up
    last_contact_at                 TIMESTAMPTZ,
    last_contact_method             TEXT,
    last_contact_notes              TEXT,
    follow_up_date                  DATE,
    follow_up_notes                 TEXT,

    -- Qualificação
    responsible_person_name         TEXT,
    responsible_person_phone_numbers TEXT[],
    current_light_bill_value        DECIMAL(10,2),
    last_kwh_consumption            DECIMAL(10,2),
    is_energy_from_other_source     BOOLEAN,
    payment_preference              TEXT,
    payment_type                    TEXT,
    bank_approval_status            TEXT,
    proposal_generated_at           TIMESTAMPTZ,
    proposal_url                    TEXT,
    client_email                    TEXT,

    -- Motivos & pipeline
    discard_reason                  TEXT,
    extended_follow_up_reason       TEXT,

    -- Auditoria
    created_at                      TIMESTAMPTZ                     DEFAULT NOW(),
    updated_at                      TIMESTAMPTZ                     DEFAULT NOW()
);

-- ==============================================================
--  Índices dedicados
-- ==============================================================
CREATE INDEX IF NOT EXISTS idx_leads_status               ON leads (status);
CREATE INDEX IF NOT EXISTS idx_leads_assigned_to_user     ON leads (assigned_to_user_id);
CREATE INDEX IF NOT EXISTS idx_leads_city_state_type      ON leads (city, state, type);
CREATE INDEX IF NOT EXISTS idx_leads_collected_at         ON leads (collected_at);
CREATE INDEX IF NOT EXISTS idx_leads_follow_up_date       ON leads (follow_up_date);

-- ==============================================================
--  Regra de domínio para status (NULL permitido)
-- ==============================================================
ALTER TABLE leads
    ADD CONSTRAINT chk_leads_status_valid
    CHECK (
        status IS NULL OR status IN (
            'Disponível',
            'Em Atendimento',
            'Aguardando Retorno',
            'Não Interessado',
            'Descartado pelo Vendedor',
            'Aguardando Aprovação do Banco',
            'Fechado',
            'Inativo'
        )
    );

-- ==============================================================
--  Trigger: mantém updated_at sempre correto
-- ==============================================================
CREATE OR REPLACE FUNCTION trg_leads_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END; $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS set_updated_at_on_leads ON leads;
CREATE TRIGGER set_updated_at_on_leads
BEFORE UPDATE ON leads
FOR EACH ROW
EXECUTE FUNCTION trg_leads_set_updated_at();

Voce falou que precisa ajustar o back porem acredito que isso eu ja fiz, olhe todo o projeto e veja se precisa de algo mais;

**Atualização de `last_interaction_at`:** -- verifique o schema dentro do projeto de back e veja se ja nao esta fazendo isso;

Após essa verificação caso ja tenha sido algo feito do que esta no seu txt, atualize ele baseado no que falta.