## 📄 Esquema da Tabela `lead_status_history`

Esta tabela registrará o histórico de mudanças de status de cada lead, fornecendo uma trilha de auditoria completa e permitindo análises mais aprofundadas sobre o ciclo de vida dos leads.

---

## 📊 Detalhes da Tabela
| Coluna       | Tipo SQL    | Descrição                                                                 |
|--------------|-------------|---------------------------------------------------------------------------|
| `id`         | UUID        | Identificador único do registro de histórico. Gerado automaticamente com `gen_random_uuid()`.     |
| `lead_id`    | UUID        | ID do lead ao qual este histórico se refere. Chave estrangeira para `leads.id`. |
| `old_status` | TEXT        | Status anterior do lead antes da alteração.                               |
| `new_status` | TEXT        | Novo status do lead após a alteração.                                     |
| `changed_by` | UUID        | ID do usuário (vendedor ou sistema) que alterou o status. Chave estrangeira para a tabela de usuários.                 |
| `changed_at` | TIMESTAMPTZ | Data e hora exata da alteração do status.                                 |
| `notes`      | TEXT        | Observações adicionais sobre a mudança de status (opcional), como o motivo da alteração.              |

---

## ⚙️ Considerações Adicionais

*   **Relacionamento:** A coluna `lead_id` deve ter uma chave estrangeira (`FOREIGN KEY`) referenciando a coluna `id` da tabela `leads`.
*   **Índices:** Recomenda-se a criação de índices nas colunas `lead_id` e `changed_at` para otimizar consultas e buscas por histórico de status de leads específicos ou em períodos determinados.
*   **Trigger:** Pode-se considerar a criação de um trigger na tabela `leads` que, a cada atualização do campo `status`, insira automaticamente um novo registro nesta tabela `lead_status_history`.

