const supabase = require("../config/supabaseClient");

/**
 * Identifica leads que precisam ser marcados como "Aguardando Reativação"
 * Critério: last_interaction_at mais antigo que 15 dias e status não seja "Descartado" ou "Fechado"
 */
async function identifyLeadsForReactivation() {
  const fifteenDaysAgo = new Date();
  fifteenDaysAgo.setDate(fifteenDaysAgo.getDate() - 15);

  const { data, error } = await supabase
    .from("leads")
    .select("id, name, last_interaction_at, status")
    .lt("last_interaction_at", fifteenDaysAgo.toISOString())
    .not("status", "in", "(Descartado pelo Vendedor,Fechado,Descartado - Inatividade,Descartado - Sem Interesse,Aguardando Reativação)")
    .not("last_interaction_at", "is", null);

  if (error) {
    console.error("Erro ao identificar leads para reativação:", error);
    throw error;
  }

  return data || [];
}

/**
 * Marca leads como "Aguardando Reativação" e define data limite
 * @param {Array} leadIds - Array de IDs dos leads para marcar
 * @param {number} reactivationDays - Dias para reativação (padrão: 30)
 */
async function markLeadsForReactivation(leadIds, reactivationDays = 30) {
  if (!leadIds || leadIds.length === 0) {
    return { updatedCount: 0 };
  }

  const reactivationDueDate = new Date();
  reactivationDueDate.setDate(reactivationDueDate.getDate() + reactivationDays);

  const { data, error } = await supabase
    .from("leads")
    .update({
      status: "Aguardando Reativação",
      last_status_update_at: new Date().toISOString(),
      reactivation_due_date: reactivationDueDate.toISOString().split('T')[0], // Apenas a data
      updated_at: new Date().toISOString()
    })
    .in("id", leadIds)
    .select();

  if (error) {
    console.error("Erro ao marcar leads para reativação:", error);
    throw error;
  }

  return { updatedCount: data ? data.length : 0, updatedLeads: data };
}

/**
 * Processa automaticamente leads inativos para reativação
 * Esta função deve ser chamada periodicamente (ex: job diário)
 */
async function processInactiveLeads() {
  try {
    console.log("Iniciando processamento de leads inativos...");
    
    const inactiveLeads = await identifyLeadsForReactivation();
    console.log(`Encontrados ${inactiveLeads.length} leads inativos`);

    if (inactiveLeads.length > 0) {
      const leadIds = inactiveLeads.map(lead => lead.id);
      const result = await markLeadsForReactivation(leadIds);
      
      console.log(`${result.updatedCount} leads marcados como "Aguardando Reativação"`);
      return {
        processedCount: inactiveLeads.length,
        updatedCount: result.updatedCount,
        leads: inactiveLeads
      };
    }

    return {
      processedCount: 0,
      updatedCount: 0,
      leads: []
    };
  } catch (error) {
    console.error("Erro no processamento de leads inativos:", error);
    throw error;
  }
}

/**
 * Busca leads que estão aguardando reativação para um vendedor específico
 * @param {string} sellerId - ID do vendedor
 */
async function getLeadsAwaitingReactivation(sellerId) {
  const { data, error } = await supabase
    .from("leads")
    .select("*")
    .eq("status", "Aguardando Reativação")
    .eq("assigned_to_user_id", sellerId)
    .order("reactivation_due_date", { ascending: true });

  if (error) {
    console.error("Erro ao buscar leads aguardando reativação:", error);
    throw error;
  }

  return data || [];
}

/**
 * Reativa um lead (muda status de "Aguardando Reativação" para novo status)
 * @param {string} leadId - ID do lead
 * @param {string} newStatus - Novo status do lead
 * @param {string} sellerId - ID do vendedor
 * @param {Object} reactivationData - Dados da reativação
 */
async function reactivateLead(leadId, newStatus, sellerId, reactivationData = {}) {
  // Verificar se o lead está realmente aguardando reativação
  const { data: currentLead, error: fetchError } = await supabase
    .from("leads")
    .select("id, status, assigned_to_user_id")
    .eq("id", leadId)
    .single();

  if (fetchError) {
    throw new Error("Lead não encontrado.");
  }

  if (currentLead.status !== "Aguardando Reativação") {
    throw new Error("Lead não está aguardando reativação.");
  }

  if (currentLead.assigned_to_user_id !== sellerId) {
    throw new Error("Lead não está atribuído a este vendedor.");
  }

  const updateData = {
    status: newStatus,
    last_status_update_at: new Date().toISOString(),
    reactivation_notes: reactivationData.notes || null,
    follow_up_date: reactivationData.follow_up_date || null,
    follow_up_notes: reactivationData.follow_up_notes || null,
    updated_at: new Date().toISOString()
  };

  // Se está iniciando atendimento, definir campos de atendimento
  if (newStatus === "Em Atendimento") {
    updateData.attended_by_user_id = sellerId;
    updateData.attended_at = new Date().toISOString();
    updateData.is_active_attendance = true;
  }

  const { data, error } = await supabase
    .from("leads")
    .update(updateData)
    .eq("id", leadId)
    .select();

  if (error) {
    throw error;
  }

  return data ? data[0] : null;
}

/**
 * Descarta um lead por inatividade
 * @param {string} leadId - ID do lead
 * @param {string} sellerId - ID do vendedor
 * @param {string} reason - Motivo do descarte
 */
async function discardLeadForInactivity(leadId, sellerId, reason = "Inatividade") {
  const discardStatus = reason === "Sem Interesse" ? "Descartado - Sem Interesse" : "Descartado - Inatividade";
  
  const { data, error } = await supabase
    .from("leads")
    .update({
      status: discardStatus,
      discard_reason: reason,
      last_status_update_at: new Date().toISOString(),
      is_active_attendance: false,
      attended_by_user_id: null,
      attended_at: null,
      updated_at: new Date().toISOString()
    })
    .eq("id", leadId)
    .eq("status", "Aguardando Reativação")
    .eq("assigned_to_user_id", sellerId)
    .select();

  if (error) {
    throw error;
  }

  if (!data || data.length === 0) {
    throw new Error("Lead não encontrado ou não pode ser descartado.");
  }

  return data[0];
}

/**
 * Estende o prazo de reativação de um lead
 * @param {string} leadId - ID do lead
 * @param {string} sellerId - ID do vendedor
 * @param {number} extensionDays - Dias para estender (10, 20, ou 30)
 * @param {string} notes - Notas sobre a extensão
 */
async function extendReactivationDeadline(leadId, sellerId, extensionDays, notes) {
  const newDueDate = new Date();
  newDueDate.setDate(newDueDate.getDate() + extensionDays);

  const { data, error } = await supabase
    .from("leads")
    .update({
      reactivation_due_date: newDueDate.toISOString().split('T')[0],
      reactivation_notes: notes,
      last_status_update_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    })
    .eq("id", leadId)
    .eq("status", "Aguardando Reativação")
    .eq("assigned_to_user_id", sellerId)
    .select();

  if (error) {
    throw error;
  }

  if (!data || data.length === 0) {
    throw new Error("Lead não encontrado ou não pode ter prazo estendido.");
  }

  return data[0];
}

module.exports = {
  identifyLeadsForReactivation,
  markLeadsForReactivation,
  processInactiveLeads,
  getLeadsAwaitingReactivation,
  reactivateLead,
  discardLeadForInactivity,
  extendReactivationDeadline
};

