const supabase = require("../config/supabaseClient");

async function countLeadsByTerm(term) {
  const { count, error } = await supabase
    .from("leads")
    .select("*", { count: "exact" })
    .eq("type", term)
    .eq("status", "Disponível");

  if (error) {
    console.error("Erro ao contar leads por termo:", error);
    return 0;
  }
  return count;
}

async function findDuplicateLead(lead) {
  const { data, error } = await supabase
    .from("leads")
    .select("id, place_id, name, formatted_address, latitude, longitude")
    .or(`name.ilike.%${lead.name.split(" ")[0]}%,formatted_address.ilike.%${lead.formatted_address.split(",")[0]}%`);

  if (error) {
    console.error("Erro ao buscar duplicatas:", error);
    return null;
  }

  const duplicate = data.find(existingLead => {
    const nameMatch = existingLead.name.toLowerCase() === lead.name.toLowerCase();
    const addressMatch = existingLead.formatted_address.toLowerCase() === lead.formatted_address.toLowerCase();

    const latDiff = Math.abs(existingLead.latitude - lead.latitude);
    const lonDiff = Math.abs(existingLead.longitude - lead.longitude);
    const coordinateMatch = latDiff < 0.0001 && lonDiff < 0.0001;

    return (nameMatch && addressMatch) || (nameMatch && coordinateMatch) || (addressMatch && coordinateMatch);
  });

  return duplicate;
}

async function processLeads(leads) {
  let newLeadsCount = 0;
  let updatedLeadsCount = 0;
  let discardedLeadsCount = 0;

  for (const lead of leads) {
    const existingLead = await findDuplicateLead(lead);

    if (existingLead) {
      discardedLeadsCount++;
      console.log(`Lead descartado (duplicado): ${lead.name} - Place ID: ${lead.place_id}`);
    } else {
      const { error: insertError } = await supabase
        .from("leads")
        .insert({
          place_id: lead.place_id,
          name: lead.name,
          formatted_address: lead.formatted_address,
          city: lead.city,
          state: lead.state,
          neighborhood: lead.neighborhood,
          formatted_phone_number: lead.formatted_phone_number,
          latitude: lead.coordinates.lat,
          longitude: lead.coordinates.lng,
          image_urls: lead.image_urls,
          type: lead.type,
          collected_at: new Date().toISOString(),
          status: "Disponível"
        });

      if (insertError) {
        console.error("Erro ao inserir novo lead:", insertError);
      } else {
        newLeadsCount++;
      }
    }
  }

  return { newLeadsCount, updatedLeadsCount, discardedLeadsCount };
}

async function getAvailableLeads() {
  const { data, error } = await supabase
    .from("leads")
    .select("*")
    .eq("status", "Disponível");

  if (error) {
    console.error("Erro ao buscar leads disponíveis:", error);
    throw error;
  }
  return data;
}

// NO ARQUIVO: src/services/leadService.js

async function updateLeadStatus(leadId, status) {
  const updateData = {
    status: status,
    updated_at: new Date().toISOString()
  };

  if (status === 'Disponível') {
    updateData.attended_by_user_id = null;
    updateData.attended_at = null;
    updateData.is_active_attendance = false;
  } else {
  }

  const { data, error } = await supabase
    .from("leads")
    .update(updateData)
    .eq("id", leadId)
    .select();

  if (error) {
    throw error;
  }
  return data ? data[0] : null;
}



async function assignLeadToSeller(leadId, sellerId) {
  const { data, error } = await supabase
    .from("leads")
    .update({
      assigned_to_user_id: sellerId,
      status: "Em Atendimento", 
      assigned_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    })
    .eq("id", leadId)
    .eq("status", "Disponível") 
    .select();

  if (error) {
    throw error;
  }
  if (!data || data.length === 0) {
    throw new Error("Lead não está disponível para atribuição.");
  }

  return data[0];
}


async function getLeadDetails(leadId) {
  const { data, error } = await supabase
    .from("leads")
    .select("*")
    .eq("id", leadId);

  if (error) {
    console.error("Erro ao buscar detalhes do lead:", error);
    throw error;
  }
  return data ? data[0] : null;
}

async function startLeadAttendance(leadId, userId) {
  const { data: currentLead, error: fetchError } = await supabase
    .from("leads")
    .select("id, status, is_active_attendance, attended_by_user_id") // Adicione attended_by_user_id para depuração
    .eq("id", leadId)
    .single();

  if (fetchError) {
    throw new Error("Lead não encontrado.");
  }


  if (currentLead.is_active_attendance) {
    throw new Error("Este lead já está sendo atendido por outro vendedor.");
  }

  const { data, error } = await supabase
    .from("leads")
    .update({
      status: "Em Atendimento",
      attended_by_user_id: userId,
      attended_at: new Date().toISOString(),
      is_active_attendance: true,
      last_status_update_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    })
    .eq("id", leadId)
    .select();

  if (error) {
    throw error;
  }

  return data ? data[0] : null;
}

async function endLeadAttendance(leadId, userId, attendanceDetails) {
  const { data: currentLead, error: fetchError } = await supabase
    .from("leads")
    .select("id, status, is_active_attendance, attended_by_user_id, contact_attempts, contact_history")
    .eq("id", leadId)
    .single();

  if (fetchError) {
    throw new Error("Lead não encontrado.");
  }

  if (!currentLead.is_active_attendance || currentLead.attended_by_user_id !== userId) {
    throw new Error("Lead não está em atendimento por este vendedor.");
  }

  const newContactAttempts = (currentLead.contact_attempts || 0) + 1;
  const newContactHistory = currentLead.contact_history || [];
  newContactHistory.push({
    date: new Date().toISOString(),
    method: attendanceDetails.last_contact_method,
    successful: attendanceDetails.contact_successful,
    notes: attendanceDetails.last_contact_notes,
    seller_id: userId,
  });

  const updateData = {
    status: attendanceDetails.status, // Novo status baseado no resultado do atendimento
    last_status_update_at: new Date().toISOString(),
    is_active_attendance: false,
    last_contact_at: new Date().toISOString(),
    last_contact_method: attendanceDetails.last_contact_method,
    last_contact_notes: attendanceDetails.last_contact_notes,
    contact_successful: attendanceDetails.contact_successful,
    contact_attempts: newContactAttempts,
    contact_history: newContactHistory,
    is_energy_from_other_source: attendanceDetails.is_energy_from_other_source,
    lead_interest_level: attendanceDetails.lead_interest_level,
    meeting_scheduled_at: attendanceDetails.meeting_scheduled_at || null,
    follow_up_date: attendanceDetails.follow_up_date || null,
    follow_up_notes: attendanceDetails.follow_up_notes || null,
    updated_at: new Date().toISOString(),
    attended_by_user_id: null, // Limpa o vendedor que estava atendendo
    attended_at: null, // Limpa a data de início do atendimento
  };

  const { data, error } = await supabase
    .from("leads")
    .update(updateData)
    .eq("id", leadId)
    .select();

  if (error) {
    throw error;
  }

  return data ? data[0] : null;
}

module.exports = {
  processLeads,
  countLeadsByTerm,
  getAvailableLeads,
  updateLeadStatus,
  assignLeadToSeller,
  getLeadDetails,
  startLeadAttendance,
  endLeadAttendance,
};